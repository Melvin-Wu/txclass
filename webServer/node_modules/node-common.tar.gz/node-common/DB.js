var Mysql = require('mysql');
var _ = require('underscore');
var Future = require('./task').future;

var pools = {};

function errResponse(err) {
    var ret = {};
    // typeof
    var arr = err && err.sqlState ? err.sqlState.match(/^#(.*)/) : 0;

    if (arr && arr.length > 0) {
        ret.retCode = arr[1];
    } else {
        ret.retCode = err.sqlState;
    }

    ret.retCode = -1000;
    ret.retObject = err.toString();
    return ret;
}

exports.init = function(dbConfig) {
    if(_.isString(dbConfig) && ENV) {
        var configs = require('./config/' + ENV + '/db.js');
        dbConfig = configs[dbConfig];
    }
    if(dbConfig) {
        //config.connectionLimit = 10;
        pools[dbConfig.database] = pools[dbConfig.database] ? pools[dbConfig.database] : Mysql.createPool(dbConfig);
        dbClass.dbName = dbConfig.database;
        return _.clone(dbClass);
    }else {
        return false;
    }
};

var dbClass = {
    dbName: '',
    getTable : function(sql) {
        var table = [];
        var result = this.query(this.dbName, sql);
        if(result.retCode == 0 && result.retObject){
            return result.retObject.rows;
        } else {
            return [];
        }
    },
    getRow : function(sql) {
        var table = this.getTable(sql);
        return table.length >= 1 ? table[0]: {};
    },
    getColumn : function(sql) {
        var table = this.getTable(sql);
        var column = [];
        var firstColumnName = table && table[0] && _.keys(table[0])[0] ? _.keys(table[0])[0]: '';
        if(firstColumnName) {
            for(var index in table) {
                var cell = table[index][firstColumnName];
                column.push(cell);
            }
        }
        return column;
    },
    getCell : function(sql) {
        var row = this.getRow(sql);
        var cellValue = _.values(row)[0];
        return cellValue;
    },
    execute : function(sql) {
        var result = this.query(this.dbName, sql);
        if(result.retCode != 0){
            console.log(result);
        }else {
            result.retObject && result.retObject.rows && result.retObject.rows.insertId ? result.insertId = result.retObject.rows.insertId: null;
        }
        return result;
    },
    //inner function
    query : function(db, sql) {
        var pool = pools[db];

        if (!pool) {
            return errResponse("con't get connection");
        }

        var f = new Future();
        pool.query(sql, function(err, rows, fields) {
            if (err) {
                f.return (errResponse(err));
            } else {
                f.return ({
                    retCode: 0,
                    retObject: {
                        rows: rows,
                        fields: fields
                    }
                });
            }
        });
        return f.wait();
    }
}
