var _ = require("underscore");

SqlBuilder = {};

SqlBuilder.buildSelectSql = function(tableName, columns, where, orderByObj, offset, limit) {
    var self = this;
    var sql = '';
    if(tableName) {
        sql = 'SELECT ' + self.buildColumns(columns) + ' FROM ' + tableName + self.buildWhere(where) 
        + self.buildOrderBy(orderByObj) + self.buildLimitSql(offset, limit);
    }
    return sql;
};
SqlBuilder.buildCountSql = function(tableName, where) {
    var self = this;
    var sql = '';
    if(tableName) {
        sql = 'SELECT COUNT(*)  FROM ' + tableName + self.buildWhere(where);
    }
    return sql;
};
SqlBuilder.buildLimitSql = function(offset, limit) {
    offset = parseInt(offset);
    limit = parseInt(limit);
    offset = _.isNumber(offset) && offset > 0 ? offset: 0;
    limit = _.isNumber(limit) && limit > 0 && limit < 100 ? limit: 100;
    return ' LIMIT ' + offset + ', ' + limit;
};
SqlBuilder.buildInsertSql = function(tableName, dataMap, dataDuplicate) {
    var self = this;
    var sql = '';
    if(tableName && dataMap) {
        var fields = [];
        var values = [];
        for(var key in dataMap) {
            var value = dataMap[key];
            fields.push('`' + key + '`');
            values.push("'" + value + "'");
        }
        sql = "INSERT INTO "+ tableName +"("+ fields.join(', ') +") VALUES("+ values.join(", ") +")";
        if(dataDuplicate && _.values(dataDuplicate).length > 0) {
            var dataMapArray = [];
            for(var key in dataDuplicate) {
                var value = dataDuplicate[key];
                value = "'" + value + "'";
                dataMapArray.push("`"+ key +"`="+ value);
            }
            sql += " ON DUPLICATE KEY UPDATE " + dataMapArray.join(',');
        }
    }
    return sql;
};
SqlBuilder.buildUpdateSql = function(tableName, dataMap, where) {
    var self = this;
    var sql = '';
    if(tableName && _.values(dataMap).length> 0 && _.values(where).length > 0) {
        var dataMapArray = [];
        for(var key in dataMap) {
            var value = dataMap[key];
            if(key.indexOf('#custom#') === 0) {
                dataMapArray.push(value);
            }else {
                value = "'" + value + "'";
                dataMapArray.push("`"+ key +"`="+ value);
            }
        }
        var whereString = self.buildWhere(where);
        sql = "UPDATE "+ tableName +" SET " + dataMapArray.join(', ') + " " + whereString;
    }
    return sql;
};
SqlBuilder.buildDeleteSql = function(tableName, where) {
    var self = this;
    var sql = '';
    if(tableName && _.keys(where) > 0) {
        sql = "DELETE FROM " + tableName + " " + self.buildWhere(where);
    }
    return sql;
};
SqlBuilder.buildColumns = function(columns) {
    var columnsString = '*';
    if(_.isObject(columns) && !_.isArray(columns)) {
        var columnsArray = [];
        for(var field in columns) {
            var alias = columns[field];
            columnsArray.push("`"+ field +"` AS `"+ alias +"`");
        }
        columns = columnsArray;
        columnsString = columns.join(', ');
    }
    return columnsString;
};
SqlBuilder.buildWhere = function(where) {
    var whereString = '';
    if(_.isString(where)) {
        whereString = where;
    }else if(_.isObject(where) && !_.isArray(where)){
        var whereArray = [];
        for(var key in where) {
            var value = where[key];
            var conditionString = '';
            if(key === '#extension#' || key.indexOf('#custom#') === 0){
                conditionString += value;
            }else {
                conditionString += '`' + key + '`';
                conditionString += _.isArray(value) ? " IN ('"+ value.join("', '") +"') ": " = '"+ value +"'";
            }
            whereArray.push(conditionString);
        }
        whereString = whereArray.length > 0 ? ' WHERE ' + whereArray.join(' AND ') + ' ' : '';
    }
    return whereString;
};
SqlBuilder.buildOrderBy = function(orderByObj) {
    var orderByArray = [];
    if(_.isObject(orderByObj) && !_.isArray(orderByObj)) {
        for(var key in orderByObj) {
            var orderType = orderByObj[key].toLowerCase() === 'desc' ? 'DESC': 'ASC';
            orderByArray.push('`'+ key +'` ' + orderType);
        }
    }
    return orderByArray.length > 0 ? ' ORDER BY ' + orderByArray.join(', ') : '';
};

module.exports = SqlBuilder;
