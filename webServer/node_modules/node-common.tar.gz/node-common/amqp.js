var amqp = require('amqplib');
var fibers = require('fibers');
var future = require('fibers/future');
var wait = future.wait;
var util = require('util');
var EventEmitter = require('events').EventEmitter;

var maxRetryTimes = 5;

amqpParseString = function(connString) {
    // 192.168.8.1:8888;192.168.8.2:9999
    if ( !connString ) {
        throw("Invalid connection string");
    }
    var ret = [];
    connString.split(/[;,]/).forEach(function(value) {
        var pair = value.split(':');
        if ( pair.length != 2 ) {
            throw("Invalid ip port pair " + value + ", 192.168.8.1:8888");
        }
        ret.push({host: pair[0], port: pair[1]});
    });
    return ret;
}

function random() {
    return Math.floor(Math.random() * (2^32 - 0) + 0);
}

function Connection(connString, vhost) {
    this.connString = connString;
    this.connTargets = this.connTargets || [];
    this.connDeadTargets = this.connDeadTargets || [];
    this.connTargets = amqpParseString(connString);
    this.vhost = vhost;
}

util.inherits(Connection, EventEmitter);

function Channel(connection) {
    this.connection = connection;
}

Connection.prototype.connect = function() {
    var self = this;
    var f = new future;
    if ( self.connTargets.length == 0 ) {
        throw ("No lived target");
    }
    var selector = random() % self.connTargets.length;
    var connTargets = self.connTargets[selector];
    var uri = new String();
    if ( self.vhost && self.vhost.length > 0 ) {
        uri = util.format('amqp://%s:%d/%s?heartbeat=300', connTargets.host, connTargets.port, self.vhost);
    }
    else {
        uri = util.format('amqp://%s:%d?heartbeat=300', connTargets.host, connTargets.port);
    }

    // console.log("connecting %s", uri);
    amqp.connect(uri).then(
        function(conn) {
            self.amqpConn = conn;
            console.log("connect to %s success", uri);
            conn.on('error', function(e) {
                console.info(e);
                self.connect();
                if(conn){
                    conn.removeAllListeners('error');
                }
            });
            f.return({retCode: 0, self: self});
        }, 
        function(e) {
            console.log("connect to %s failed", uri, e);
            f.return({retCode: -1, retObject: e});
        }
    ).then(null, console.warn);
    return f;
}

Connection.prototype.destroy = function () {
    this.amqpConn.close();
    delete this.amqpConn;
}

Connection.prototype.openChannel = function () {
    var self = this;
    var f = new future;
    if ( !self.amqpConn ) {
        throw ("No lived connection");
    }
    self.amqpConn.createChannel().then(
        function(ch) {
            var channel = new Channel(self);
            channel.channel = ch;
            f.return({retCode: 0, retObject: channel});
        }, 
        function(e) {
            f.return({retCode: -1, retObject: e});
        }
    );
    return f;
}

Channel.prototype.declareQueue = function (queueName, options) {
    var self = this;
    var f = new future;
    self.channel.assertQueue(queueName, options).then(
        function(queue) {
            f.return({retCode: 0, retObject: queue});
        },
        function(e) {
            f.return({retCode: -1, retObject: e});
        }
    );
    return f;
}

Channel.prototype.declareExchange = function (exchangeName, type, options) {
    var self = this;
    var f = new future;
    self.channel.assertExchange(exchangeName, type, options).then(
        function(exchange) {
            f.return({retCode: 0, retObject: exchange});
        },
        function(e) {
            f.return({retCode: -1, retObject: e});
        }
    );
    return f;
}

Channel.prototype.bindQueue = function (queue, source, pattern, args) {
    var self = this;
    var f = new future;
    self.channel.bindQueue(queue, source, pattern, args).then(
        function(exchange) {
            f.return({retCode: 0, retObject: {}});
        },
        function(e) {
            f.return({retCode: -1, retObject: e});
        }
    );
    return f;
}

Channel.prototype.publish = function (exchange, routingKey, content, options) {
    var self = this;
    var f = new future;
    var ok = self.channel.publish(exchange, routingKey, content, options);
    if ( ok ) {
        f.return({retCode: 0, retObject: {}});
    }
    else {
        f.return({retCode: -1, retObject: {}});
    }
    return f;
}

Channel.prototype.consume = function (queue, callback, options) {
    var self = this;
    var ok = self.channel.consume(queue, callback, options);
    return {retCode: 0, retObject: {}};
}

Channel.prototype.prefetch = function(num){
    var self = this;
    self.channel.prefetch(num);
}

Channel.prototype.ack = function(msg){
    var self = this;
    self.channel.ack(msg);
}

exports.Connection = Connection;
exports.Channel = Channel;

