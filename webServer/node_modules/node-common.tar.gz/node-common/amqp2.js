var amqp = require('amqp');
var util = require('util');
var fibers = require('fibers');
var future = require('fibers/future');


function random() {
    return Math.floor(Math.random() * (2 ^ 32 - 0) + 0);
}

exports.GetTarget = GetTarget = function(connTargets, vhost) {
    var selector = random() % connTargets.length;
    var connTargets = connTargets[selector];
    var uri = new String();

    if (connTargets.length == 0) {
        throw ("No lived target");
    }

    vhost = vhost == '/' ? "" : vhost;

    if (vhost && vhost.length > 0) {
        uri = util.format('amqp://%s:%d/%s', connTargets.host, connTargets.port, vhost);
        return uri;

    } else {
        uri = util.format('amqp://%s:%d', connTargets.host, connTargets.port);
        return uri;
    }
    return false;
}


exports.ParseString = ParseString = function(connString) {
    // 192.168.8.1:8888;192.168.8.2:9999
    if (!connString) {
        throw ("Invalid conn string");
    }
    var ret = [];
    connString.split(/[;,]/).forEach(function(value) {
        var pair = value.split(':');
        if (pair.length != 2) {
            throw ("Invalid ip port pair " + value + ", 192.168.8.1:8888");
        }
        ret.push({
            host: pair[0],
            port: pair[1]
        });
    });
    return ret;
}

exports.CreateConnection = CreateConnection = function(uri) {
    var f = new future();
    function fail_cb(err) {
        console.log("connect to %s failed", uri, err);
        this.removeListener('ready', success_cb);
        f.return(false);
    }
    function success_cb() {
        this.removeListener('error', fail_cb);
        f.return(this);
    }

    amqp.createConnection({
        url: uri,
        heartbeat: 10
    }, {
        defaultExchangeName: '',
        reconnect: true,
        reconnectBackoffStrategy: 'linear',
        reconnectExponentialLimit: 120000,
        reconnectBackoffTime: 1000
    })
    .once('error', fail_cb)
    .once('ready', success_cb)
    .on('ready', function() {
        console.info("connect to %s success", this.options.url);
    })
    .on('close', function() {
        console.info("connection %s closed", this.options.url);
    })
    .on('error', function(err) {
        console.info("connection %s error", this.options.url, err.stack);
    });

    return f.wait();
}

exports.Exchange = Exchange = function(conn, name, options) {
    var f = new future();
    options = options || {};

    function fail_cb(err) {
        this.removeListener('open', success_cb);
        f.return(false);
    }
    function success_cb() {
        this.removeListener('error', fail_cb);
        f.return(this);
    }

    conn.exchange(name, options)
    .once('error', fail_cb)
    .once('open', success_cb)
    .on('open', function() {
        console.info("open exchange %s success", this.name);
    })
    .on('error', function(err) {
        console.info("exchange %s error", this.name, err.stack);
    });

    return f.wait();
}

exports.Queue = Queue = function(conn, name, options) {
    var f = new future();
    options = options || {};

    function fail_cb(err) {
        this.removeListener('open', success_cb);
        f.return(false);
    }
    function success_cb() {
        this.removeListener('error', fail_cb);
        f.return(this);
    }

    conn.queue(name, options)
    .once('error', fail_cb)
    .once('open', success_cb)
    .on('open', function() {
        console.info("open queue %s success", this.name);
    })
    .on('queueBindOk', function() {
        console.info("bind queue %s success", this.name);
    })
    .on('error', function(err) {
        console.info("queue %s error", this.name, err.stack);
    });

    return f.wait();
}

exports.QueueBind = QueueBind = function(queue, exchange, routing_key) {
    var f = new future();

    function fail_cb(err) {
        this.removeListener('queueBindOk', success_cb);
        f.return(false);
    }
    function success_cb() {
        this.removeListener('error', fail_cb);
        f.return(true);
    }

    queue
    .once('error', fail_cb)
    .once('queueBindOk', success_cb)
    .bind(exchange, routing_key);

    return f.wait();
}
