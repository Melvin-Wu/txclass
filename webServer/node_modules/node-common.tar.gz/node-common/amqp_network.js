var Amqp = require('./amqp');
var Util = require('util');
var FunctionPool = require("./function_pool").functionPool();
var Task = require('./task');
var UMessage = require("./umessage");

var amqpConnection = {};

var reqExchange = exports.reqExchange = "general_req";
var resExchange = exports.resExchange = "general_res";

var timeouterPool = exports.timeouterPool = {};
var flowPool = exports.flowPool = {};
GLOBAL.logger = GLOBAL.logger || console;
GLOBAL.REQUEST_NUMBER = GLOBAL.REQUEST_NUMBER || 0;

function reconnect(mqcluster, vhost) {
    var i = 0;
    var ok = false;
    var ret = {};

    // 尝试连接服务器
    amqpConnection = new Amqp.Connection(mqcluster, vhost);
    for (i = 0; i < 3; i++) {
        if (0 != (ret = amqpConnection.connect().wait().retCode)) {
            GLOBAL.logger.warn("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "Connect failed", ret.retObject);
        } else {
            ok = true;
            break;
        }
    }
    if (!ok) {
        GLOBAL.logger.error("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "Final connect failed");
        return false;
    }

    amqpConnection.on('error', function(e) {
        GLOBAL.logger.error("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "amqp connection error: ", e);

        Fibers(function() {
            init();
        }).run();
    });
    return true;
}


function consume_fn(msg) {
    var obj;

    try {
        GLOBAL.logger.info(UMessage.DebugString(msg.content));
        obj = UMessage.Parse(msg.content);
    } catch (e) {
        GLOBAL.logger.error("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "parse message error", e);
        amqpConnection.channel.ack(msg);
        return;
    }

    var target_entity = 0;
    if (obj.head.version == 2) {
        target_entity = obj.head.dest_entity;
    } else {
        target_entity = obj.head.source_entity;
    }

    var task = Task.taskQueue().get(target_entity);
    if (task) {
        trigger(obj.head.flow_no, obj);
        amqpConnection.channel.ack(msg);
    } else {
        var func = FunctionPool.get(obj.head.message_type);
        if (!func) {
            GLOBAL.logger.info("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "discard new message", obj);
            amqpConnection.channel.ack(msg);
        } else {
            task = new Task.task(func);
            task.sendResponse = function(responseObject) {
                var buf = UMessage.Serialize(responseObject.msgObject);
                GLOBAL.logger.info(UMessage.DebugString(buf));
                amqpConnection.channel.publish(resExchange, msg.properties.replyTo, buf, msg.options);
                amqpConnection.channel.ack(msg);
            };
            task.run(obj);
        }
    }
}

// 回包处理
var trigger = exports.trigger = function(flow_no, resObject) {
    clearTimeout(timeouterPool[flow_no]);
    delete timeouterPool[flow_no];

    var callback = flowPool[flow_no];
    delete flowPool[flow_no];
    if (typeof callback === "function") {
        callback(flow_no, resObject);
    }
};

// 绑定回包处理
exports.attach = function(flow_no, callback) {
    flowPool[flow_no] = callback;
};

// 解绑回包处理
exports.detach = function(flow_no) {
    delete flowPool[flow_no];
};

exports.init = function(mqcluster, vhost, routingKeys, replyQueue, reqQueue) {
    // 建立连接
    if (!reconnect(mqcluster, vhost)) {
        return false;
    }

    // 打开信道
    if ((ret = amqpConnection.openChannel().wait()).retCode != 0) {
        amqpConnection.amqpDestroy();
        return false;
    }
    amqpConnection.channel = ret.retObject;

    //amqpConnection.channel.prefetch(1);

    if ((ret = amqpConnection.channel.declareQueue(replyQueue, {
        exclusive: true,
        autoDelete: true,
        durable: false
    }).wait()).retCode != 0) {
        amqpConnection.amqpDestroy();
        return false;
    };

    amqpConnection.replyQueue = ret.retObject;


    // 声明exchange
    if ((ret = amqpConnection.channel.declareExchange(reqExchange, "topic", {
        durable: true
    }).wait()).retCode != 0) {
        amqpConnection.amqpDestroy();
        return false;
    }

    // 声明exchange
    if ((ret = amqpConnection.channel.declareExchange(resExchange, "topic", {
        durable: true
    }).wait()).retCode != 0) {
        amqpConnection.amqpDestroy();
        return false;
    }

    if (reqQueue && routingKeys) {

        // 声明持久队列
        if ((ret = amqpConnection.channel.declareQueue(reqQueue, {
            durable: true
        }).wait()).retCode != 0) {
            amqpConnection.amqpDestroy();
            return false;
        };

        amqpConnection.reqQueue = ret.retObject;

        for (var i = 0; i < routingKeys.length; i++) {
            // 绑定处理请求队列
            if ((ret = amqpConnection.channel.bindQueue(amqpConnection.reqQueue.queue, reqExchange, routingKeys[i], {}).wait()).retCode != 0) {
                amqpConnection.amqpDestroy();
                return false;
            }
        }


        // 注册请求 consume
        amqpConnection.channel.consume(amqpConnection.reqQueue.queue, consume_fn);

        GLOBAL.logger.info("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "bindQueue req Queue", amqpConnection.reqQueue.queue);
    }


    // 绑定reply队列
    var pattern = amqpConnection.replyQueue.queue;
    if ((ret = amqpConnection.channel.bindQueue(amqpConnection.replyQueue.queue, resExchange, pattern, {}).wait()).retCode != 0) {
        amqpConnection.amqpDestroy();
        return false;
    }


    // 注册回包consume
    amqpConnection.channel.consume(amqpConnection.replyQueue.queue, consume_fn);

    return amqpConnection;
}

if (require.main == module) {
    var Fibers = require("fibers");
    Fibers(function() {
        exports.init('192.168.8.152:5672', '/', [], '');
    }).run();
}
