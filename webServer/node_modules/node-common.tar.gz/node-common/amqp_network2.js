var util = require('util');
var FunctionPool = require("./function_pool").functionPool();
var Task = require('./task');
var Amqp = require('./amqp2');
var UMessage = require("./umessage");


var amqpConnection = {};
var reqExchange = exports.reqExchange = "general_req";
var resExchange = exports.resExchange = "general_res";
var timeouterPool = exports.timeouterPool = {};

var conn = null;
var reqExchangeObj = null;
var resExchangeObj = null;
var reqQueueObj = null;
var resQueueObj = null;


GLOBAL.logger = GLOBAL.logger || console;
GLOBAL.REQUEST_NUMBER = GLOBAL.REQUEST_NUMBER || 0;


function consume_fn(message, headers, deliveryInfo, messageObject) {
    var obj;
    try {
        GLOBAL.logger.info(UMessage.DebugString(message.data));
        obj = UMessage.Parse(message.data);
    } catch (e) {
        GLOBAL.logger.error("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "parse message error", e);
        messageObject.acknowledge(true);
        return;
    }

    var target_entity = 0;
    if (obj.head.version == 2) {
        target_entity = obj.head.dest_entity;
    } else {
        target_entity = obj.head.source_entity;
    }

    var task = Task.taskQueue().get(target_entity);
    if (task) {
        var timeouter = timeouterPool[obj.head.flow_no];
        if (timeouter) {
            delete timeouterPool[obj.head.flow_no];
            clearTimeout(timeouter);
        }

        task.run(obj);
    } else {
        var func = FunctionPool.get(obj.head.message_type);
        if (!func) {
            GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "discard new message", obj);
            messageObject.acknowledge(true);
        } else {
            task = new Task.task(func);
            task.sendResponse = function(responseObject) {
                var buf = UMessage.Serialize(responseObject.msgObject);
                GLOBAL.logger.info(UMessage.DebugString(buf));
                resExchangeObj.publish(messageObject.replyTo, buf, messageObject.options);
            };
            task.run(obj);
        }
    }
}


exports.init = function(mqcluster, vhost, routing_keys, reply_queue_name, req_queue_name) {
    var uri = Amqp.GetTarget(Amqp.ParseString(mqcluster));

    conn = Amqp.CreateConnection(uri);
    if (!conn) {
        console.info("can not connect %s", uri);
        return;
    }

    reqExchangeObj = Amqp.Exchange(conn, reqExchange, {
        type: 'topic',
        durable: true,
        passive: true
    });

    if (!reqExchangeObj) {
        console.info("can not create exchange %s %s", reqExchange, uri);
        conn.disconnect();
        return;
    }

    resExchangeObj = Amqp.Exchange(conn, resExchange, {
        type: 'topic',
        durable: true,
        passive: true
    });

    if (!resExchangeObj) {
        console.info("can not create exchange %s %s", resExchange, uri);
        conn.disconnect();
        return;
    }


    if (req_queue_name && routing_keys) {

        reqQueueObj = Amqp.Queue(conn, req_queue_name, {
            passive: true,
            durable: true
        });


        if (!reqQueueObj) {
            console.info("can not create req queue %s %s", reply_queue_name, uri);
            conn.disconnect();
            return;
        }

        for (var i = 0; i < routing_keys.length; i++) {
            var ret = Amqp.QueueBind(reqQueueObj, reqExchange, routing_keys[i]);
            if (!ret) {
                console.info("can not bind queue routing_keys %s %s", req_queue_name, routing_keys[i]);
                conn.disconnect();
                return;
            }
        }

        // 注册请求 consume
        reqQueueObj.subscribe(consume_fn, {
            prefetchCount: 1
        });
    }


    replyQueueObj = Amqp.Queue(conn, reply_queue_name, {
        exclusive: true,
        autoDelete: true,
        durable: false
    });


    if (!replyQueueObj) {
        console.info("can not create reply queue %s %s", reply_queue_name, uri);
        //conn.disconnect();
        return;
    }

    // 绑定reply队列
    var ret = Amqp.QueueBind(replyQueueObj, resExchange, replyQueueObj.name);

    if (!ret) {
        console.info("can not bind queue routing_keys %s %s", resExchange, replyQueueObj.name);
        //conn.disconnect();
        return;
    }

    // 注册回包consume
    replyQueueObj.subscribe(consume_fn, {
        prefetchCount: 1,
        ack: true
    });

    amqpConnection.conn = conn;
    amqpConnection.resExchangeObj = resExchangeObj;
    amqpConnection.reqExchangeObj = reqExchangeObj;
    amqpConnection.reqQueueObj = reqQueueObj;
    amqpConnection.replyQueueObj = replyQueueObj;
    amqpConnection.replyQueue = replyQueueObj.name;

    return amqpConnection;
}

if (require.main == module) {
    var Fibers = require("fibers");
    Fibers(function() {
        exports.init('192.168.8.156:5672', '/', [], '');
    }).run();
}
