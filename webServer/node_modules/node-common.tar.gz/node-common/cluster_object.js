
function clusterParseString(connString) {
    // 192.168.8.1:8888;192.168.8.2:9999
    if ( !connString ) {
        throw "Invalid connection string";
    }
    var ret = [];
    connString.split(/[;,]/).forEach(function(value) {
        var pair = value.split(':');
        if ( pair.length != 2 ) {
            throw ("Invalid ip port pair " + value + ", 192.168.8.1:8888");
        }
        ret.push({host: pair[0], port: pair[1]});
    });
    return ret;
}

function random() {
    return Math.floor(Math.random() * (2^32 - 0) + 0);
}

clusterObject = function(clusterString) {
    this.cluster = clusterParseString(clusterString);
}

clusterObject.prototype.select = function() {
    var self = this;
    if ( self.cluster.length == 0 ) {
        throw "Cluster's size is zero";
    }
    var sel = random() % self.cluster.length;
    return self.cluster[sel];
}

clusterObject.prototype.del = function(idx) {
    var self = this;
    if ( self.cluster.length < idx ) {
        return;
    }
    delete self.cluster[idx];
}

exports.clusterObject = clusterObject;
