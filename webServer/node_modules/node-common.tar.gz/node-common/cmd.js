var Future = require("fibers/future");
var fs = require("fs");
var child_process = require("child_process");

var cmd = {};

cmd.exec = function(commond){
    var f = new Future;
    child_process.exec(commond, function(error, stdout, stderr){
        f.return({error:error, stdout:stdout, stderr:stderr}); 
    }); 
    return f.wait();
} 


module.exports = cmd;

if (require.main == module) {
    var Fibers = require('fibers');
    Fibers(function(){
        console.info(cmd.exec("ping -c 1 192.168.8.151"));
    }).run();
}

