module.exports = {
    'usecure': {
        'database' : 'usecure',
        'host' : '192.168.8.200',
        'port' : '3306',
        'user' : 'root',
        'password' : ''
    },
    'uresource': {
        'database' : 'uaccount',
        'host' : '192.168.8.200',
        'port' : '3306',
        'user' : 'root',
        'password' : ''
    }
};
