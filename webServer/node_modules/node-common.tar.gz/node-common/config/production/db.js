module.exports = {
    'usecure': {
        'database' : 'usecure',
        'host' : '172.17.100.2',
        'port' : '3306',
        'user' : 'ucloud',
        'password' : 'ucloud.cn'
    },
    'uresource': {
        'database' : 'uaccount',
        'host' : '172.17.100.2',
        'port' : '3306',
        'user' : 'ucloud',
        'password' : 'ucloud.cn'
    }
};
