Task = require('./task.js')
_innerPool = function() {
}

functionPool = function() {
    var _p = new _innerPool();
    return function() {
        return _p;
    }
}();

_innerPool.prototype.register = function(id, func, duration, defer) {
    var self = this;
    self.pool = self.pool || {};
    self.pool[id] = self.pool[id] || {};
    self.pool[id].func = func;
    self.pool[id].duration = duration;
    self.pool[id].last_runtime = Date.now();
    if(duration && !defer){
        new Task.task(func).run();
    }
}

_innerPool.prototype.get = function(id) {
    var self = this;
    if ( !self.pool ) {
        return undefined;
    }

    if ( self.pool[id] ) {
        return self.pool[id].func;
    }
    else {
        return undefined;
    }
}

_innerPool.prototype.getAll = function() {
    var self = this;
    if ( self.pool ) {
        return self.pool;
    }
    else {
        return undefined;
    }
}

exports.functionPool = functionPool;

setInterval(function() {
    var pool = functionPool().getAll();
    for ( key in pool ) {
        if ( pool[key].duration && pool[key].last_runtime && Date.now() - pool[key].last_runtime  > pool[key].duration  ) {
            pool[key].last_runtime = Date.now();
            var t = new Task.task(pool[key].func);
            t.run();
        }
    }
}, 1000);

