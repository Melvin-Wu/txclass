module.exports = require('fibers/future');
