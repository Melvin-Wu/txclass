var request = require("request");
var Future = require('fibers/future');

exports.request = function(uri, data){
    /*
        uri {
            uri,  
            method,
            form 可选 POST 时使用 
        }
    */ 

    var f = new Future;
    request(uri, function(error, response, body) {
        if(error){
            f.return(false); 
        }else{
            f.return(body); 
        }     
    });
    return f.wait();
}

if(require.main == module){
    var Fibers = require("fibers");
    Fibers(function(){
        console.info(exports.request({uri:"http://www.sina.com.cn/", method:"GET"}, {a:"b"}));
    }).run();
}
