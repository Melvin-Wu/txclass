var UMessage = require("./umessage.js");
var AmqpNetwork = require("./amqp_network");

exports.build = function(service, reqMsg, req) {
    var reqArr = reqMsg.split(".");
    var reqBody = reqArr[2];
    req._extensionType_ = reqMsg;
    var message_type = reqArr[0] + "." + reqArr[1] + "." + reqArr[2].toUpperCase();
    var head = {
        message_type: UMessage.EnumValue(message_type)
    };
    req._extensionType_ = reqMsg;

    var body = {};
    body[reqBody] = req;

    var reqObj = {
        address: service.ip, 
        port: service.port,
        msgObject: UMessage.makeObject(head, body)
    };
    return reqObj;
}

exports.buildAmqp = function(reqMsg, req) {
    var reqArr = reqMsg.split(".");
    var reqBody = reqArr[2];
    req._extensionType_ = reqMsg;
    var message_type = reqArr[0] + "." + reqArr[1] + "." + reqArr[2].toUpperCase();
    var head = {
        message_type: UMessage.EnumValue(message_type)
    };
    req._extensionType_ = reqMsg;

    var body = {};
    body[reqBody] = req;

    var reqObj = {
        exchange: AmqpNetwork.reqExchange,
        key: message_type,
        msgObject: UMessage.makeObject(head, body),
        channel: amqpConnection.channel,
        options: {
            replyTo: amqpConnection.replyQueue.queue
        }
    };
    return reqObj;
}
