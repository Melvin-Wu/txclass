var Http = require('http');
var Fs = require('fs');
var Uuid = require('uuid');
var Exec = require('child_process').exec;
var Fibers = require('fibers');
var Future = require('fibers/future');

var readdir = Future.wrap(Fs.readdir);
var stat = Future.wrap(Fs.stat);

exports.downloadPlugin = function(pluginPath) {
    var f = new Future;
    var tempFile = '/tmp/' + Uuid.v4();
    var stream = Fs.createWriteStream(tempFile, {flags: 'w'});
    // console.log('%s temp to %s', pluginPath, tempFile);
    Http.get(pluginPath, function(res) {
        res.pipe(stream);
        res.on('end', function() {
            Exec('mkdir -p ~/node_framework/plugin; tar -C ~/node_framework/plugin/ -zvxf ' + tempFile, function(err, stdout, stderr) {
                if ( err ) {
                    f.return({retCode:-1, retObject: err});
                }
                else {
                    f.return({retCode:0, retObject:{}});
                }
            });
        });
    }).on('error', function(e) {
        f.return({retCode:0, retObject:{}});
    });
    return f;
}

//file_module and npm_module
exports.load = function(path) {
    var dirs = readdir(path).wait();
    dirs.forEach(function(v) {
        var _module_path = path + '/' + v;
        var _stats = stat(_module_path).wait();
        if(_stats.isFile() && /\.js$/.test(v)){
            require(_module_path);
        }else if(_stats.isDirectory()){
            require(_module_path);
        }
    });
}

if(require.main == module){
    Fibers(function(){
        var path = __dirname + '/plugin' ;
        exports.load(path);
    }).run();
}
