var Future = require("fibers/future");
var Wait = Future.wait;
var UMessage = require("./umessage.js");
var AmqpNetwork = require("./amqp_network");

var timeouterPool = AmqpNetwork.timeouterPool;

GLOBAL.logger = GLOBAL.logger || console;
GLOBAL.REQUEST_NUMBER = GLOBAL.REQUEST_NUMBER || 0;

module.exports = function(task, reqArray) {
    /*
    exchange: reqExchange, 
    key: "UCLOUD.UCM.GET_CONFIG_REQUEST", 
    msgObject: obj, 
    channel: self.channel, 
    options: {replyTo: self.replyQueue.queue}, 
*/
    var resArray = [];
    var resIndex = {};
    var reqCount = 0;
    var resCount = 0;
    if (reqArray && reqArray.length > 0) {
        var f = new Future();
        reqArray.forEach(function(val) {
            val.msgObject.head.source_entity = task.id;

            //设置请求的默认超时时间
            val.timeout = val.timeout || (GLOBAL.RPC_TIMEOUT || 10000);

            var buf = UMessage.Serialize(val.msgObject);
            resIndex[val.msgObject.head.flow_no] = reqCount++;
            AmqpNetwork.attach(val.msgObject.head.flow_no, function(flow_no, resObject) {
                if (resObject) {
                    if (resIndex.hasOwnProperty(flow_no)) {
                        resArray[resIndex[flow_no]] = resObject;
                    } else {
                        GLOBAL.logger.error("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "Invalid flow_no %d", flow_no);
                    }
                }

                if (++resCount == reqArray.length) {
                    f.return();
                }
            });
            val.channel.publish(val.exchange, val.key, buf, val.options);

            GLOBAL.logger.info(UMessage.DebugString(buf));

            if (val.timeout) {
                var timeouter = setTimeout(function() {

                    GLOBAL.logger.info("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "timeout");
                    GLOBAL.logger.info("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", val.msgObject);
                    AmqpNetwork.trigger(val.msgObject.head.flow_no, false);

                }, val.timeout);

                timeouterPool[val.msgObject.head.flow_no] = timeouter;
            }


        });

        f.wait();

        reqArray.forEach(function(val) {
            var timeouter = timeouterPool[val.msgObject.head.flow_no];
            if (timeouter) {
                clearTimeout(timeouter);
                delete timeouterPool[val.msgObject.head.flow_no]
            }
        });
    }

    return resArray;
}
if (require.main == module) {
    var Task = require("./task.js");
    new Task.task(function() {
        var task = this;
        var amqpConnection = AmqpNetwork.init('192.168.8.152:5672', '/', [], '');
        var account_id = [10905];

        var reqs = [];
        var messageType = "ucloud.uorganization.GET_ACCOUNT_REQUEST";

        var obj = UMessage.makeObject({
            message_type: UMessage.EnumValue(messageType)
        }, {
            get_account_request: {
                account_id: account_id,
                _extensionType_: "ucloud.uorganization.get_account_request"
            }
        });
        reqs.push({
            exchange: AmqpNetwork.reqExchange,
            key: messageType,
            msgObject: obj,
            timeout: 100,
            channel: amqpConnection.channel,
            options: {
                replyTo: amqpConnection.replyQueue.queue
            }
        });

        var obj = UMessage.makeObject({
            message_type: UMessage.EnumValue(messageType)
        }, {
            get_account_request: {
                account_id: account_id,
                _extensionType_: "ucloud.uorganization.get_account_request"
            }
        });
        reqs.push({
            exchange: AmqpNetwork.reqExchange,
            key: messageType,
            msgObject: obj,
            timeout: 1000,
            channel: amqpConnection.channel,
            options: {
                replyTo: amqpConnection.replyQueue.queue
            }
        });

        var resArray = module.exports(task, reqs);
        console.log(resArray);
        process.exit();

    }).run();
}
