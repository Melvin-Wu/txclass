var Task = require("./task.js");
var Future = require("fibers/future");
var Wait = Future.wait;
var UMessage = require("./umessage.js");
var AmqpNetwork = require("node-common/amqp_network");

var timeouterPool = AmqpNetwork.timeouterPool;

GLOBAL.logger = GLOBAL.logger || console;
GLOBAL.REQUEST_NUMBER = GLOBAL.REQUEST_NUMBER || 0;

module.exports = function(task, reqArray) {
    /*
    exchange: reqExchange, 
    key: "UCLOUD.UCM.GET_CONFIG_REQUEST", 
    msgObject: obj, 
    channel: self.channel, 
    options: {replyTo: self.replyQueue.queue}, 
*/
    var resArray = [];
    var resIndex = {};
    var reqCount = 0;
    var resCount = 0;
    reqArray.forEach(function(val) {
        val.msgObject.head.source_entity = task.id;

        //设置请求的默认超时时间
        val.timeout = val.timeout || (GLOBAL.RPC_TIMEOUT || 10000);

        var buf = UMessage.Serialize(val.msgObject);
        resIndex[val.msgObject.head.flow_no] = reqCount++;
        val.amqpConn.reqExchangeObj.publish(val.key, buf, {replyTo:val.amqpConn.replyQueue});

        GLOBAL.logger.info(UMessage.DebugString(buf));

        if (val.timeout) {
            var timeouter = setTimeout(function() {

                GLOBAL.logger.info("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "timeout");
                GLOBAL.logger.info("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", val.msgObject);

                clearTimeout(timeouter);
                delete timeouterPool[val.msgObject.head.flow_no]
                resCount++;
                if (task) {
                    task.run(false);
                }
            }, val.timeout);

            timeouterPool[val.msgObject.head.flow_no] = timeouter;
        }


    });

    while (1) {
        var resObject = task.yield();


        if (resObject) {

            var timeouter = timeouterPool[resObject.head.flow_no];
            if (timeouter) {
                clearTimeout(timeouter);
                delete timeouterPool[resObject.head.flow_no];
            }

            if (resIndex.hasOwnProperty(resObject.head.flow_no)) {
                resArray[resIndex[resObject.head.flow_no]] = resObject;
                resCount++;
            } else {
                GLOBAL.logger.error("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "Invalid flow_no %d", resObject.head.flow_no);
            }
        }

        if (resCount == reqArray.length) {
            break;
        }
    }

    reqArray.forEach(function(val) {
        var timeouter = timeouterPool[val.msgObject.head.flow_no];
        if (timeouter) {
            clearTimeout(timeouter);
            delete timeouterPool[val.msgObject.head.flow_no]
        }
    });

    return resArray;
}
