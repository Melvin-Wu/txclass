var Task = require("./task.js");
var Fibers = require("fibers");
var Future = require("fibers/future");
var Wait = Future.wait;
var UMessage = require("./umessage.js");
var HeadBodyBuffers = require('head_body_buffers').HeadBodyBuffers;
var FunctionPool = require("./function_pool.js").functionPool();
var Net = require('net');

var connectionPool = {};
var timeouterPool = {};
var flowPool = {};

GLOBAL.logger = GLOBAL.logger || console;
GLOBAL.REQUEST_NUMBER = GLOBAL.REQUEST_NUMBER || 0;

// 回包处理
function trigger(flow_no, resObject) {
    clearTimeout(timeouterPool[flow_no]);
    delete timeouterPool[flow_no];

    var callback = flowPool[flow_no];
    delete flowPool[flow_no];
    if (typeof callback === "function") {
        callback(flow_no, resObject);
    }
};

// 绑定回包处理
function attach(flow_no, callback) {
    flowPool[flow_no] = callback;
};

// 解绑回包处理
function detach(flow_no) {
    delete flowPool[flow_no];
};

function getConnection(address, port) {
    var conn_key = address + ":" + port;
    var client = connectionPool[conn_key];
    if (client) {
        return client;
    } else {
        var f = new Future();

        client = new Net.Socket();

        client.setKeepAlive(true, 10);

        client.on('end', function() {
            console.info("end");
        });

        client.on('error', function(error) {
            if (error.code == 'ECONNREFUSED') {
                f.
                return (false);
            } else {
                if (client.buffers) {
                    client.buffers.removeAllListeners();
                }
                client.removeAllListeners();
                client.end();
                delete connectionPool[conn_key];
                client = null;
            }
        })

        client.on('close', function(e) {
            GLOBAL.logger.info("rpc tcp connection on close");
            if (client.buffers) {
                client.buffers.removeAllListeners();
            }
            client.removeAllListeners();
            delete connectionPool[conn_key];
            client = null;
        });

        client.connect(port, address, function() {

            connectionPool[conn_key] = client;

            client.buffers = new HeadBodyBuffers(UMessage.tcpHeadSize(), function(data) {
                return UMessage.expectSize(data);
            });

            client.on('data', function(buffer) {
                client.buffers.addBuffer(buffer);
            });

            client.buffers.on('packet', function(buf) {

                try {
                    GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "SOURCE : ", client.remoteAddress, client.remotePort);
                    //GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", UMessage.DebugString(buf.slice(4)));
                } catch (e) {
                    GLOBAL.logger.info(e);
                }

                var obj = UMessage.decodeMessage(buf);

                if (!obj || !obj.head || !obj.head.message_type) {

                    GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "Invalid request message");
                    return;
                }
                var target_entity = 0;
                if (obj.head.version == 2) {
                    target_entity = obj.head.dest_entity;
                } else {
                    target_entity = obj.head.source_entity;
                }

                var task = Task.taskQueue().get(target_entity);
                if (task) {
                    trigger(obj.head.flow_no, obj);
                }
            });
            f.
            return (client);
        });
        return f.wait();
    }
}

module.exports = function(task, reqArray) {
    /*
    connection: connection, 
    address: ip address/hostname
    port: port
    msgObject: obj, 
*/
    var resArray = [];
    var resIndex = {};
    var reqCount = 0;
    var resCount = 0;

    if (reqArray && reqArray.length > 0) {
        var f = new Future();
        reqArray.forEach(function(val) {
            getConnection(val.address, val.port);
        });

        reqArray.forEach(function(val) {
            val.msgObject.head.source_entity = task.id;

            //设置请求的默认超时时间
            val.timeout = val.timeout || (GLOBAL.RPC_TIMEOUT || 10000);

            var buf = UMessage.encodeMessage(val.msgObject);
            resIndex[val.msgObject.head.flow_no] = reqCount++;
            attach(val.msgObject.head.flow_no, function(flow_no, resObject) {
                if (resObject) {
                    if (resIndex.hasOwnProperty(flow_no)) {
                        resArray[resIndex[flow_no]] = resObject;
                    } else {
                        GLOBAL.logger.error("REQUEST_NUMBER:", "("+GLOBAL.REQUEST_NUMBER+")", "Invalid flow_no %d", flow_no);
                    }
                }

                if (++resCount == reqArray.length) {
                    f.return();
                }
            });
            var connection = getConnection(val.address, val.port);


            if (connection) {
                connection.write(buf);

                GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "TARGET: ", connection.remoteAddress, connection.remotePort);
                //GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", UMessage.DebugString(buf.slice(4)));

                if (val.timeout) {
                    var timeouter = setTimeout(function() {

                        GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "timeout");
                        GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", val.msgObject);

                        trigger(val.msgObject.head.flow_no, false);
                    }, val.timeout);

                    timeouterPool[val.msgObject.head.flow_no] = timeouter;
                }
            } else {
                GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "connection  lost not send request or connect error")
                GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", val.msgObject);
                trigger(val.msgObject.head.flow_no, false);
            }

        });

        f.wait();

        reqArray.forEach(function(val) {
            var timeouter = timeouterPool[val.msgObject.head.flow_no];
            if (timeouter) {
                clearTimeout(timeouter);
                delete timeouterPool[val.msgObject.head.flow_no]
            }
        });
    }

    return resArray;
}


if (require.main == module) {
    GLOBAL.RPC_TIMEOUT = 10000;
    new Task.task(function() {
        var self = this;

        var messageType = "ucloud.uaccount.GET_USER_ALL_PERMISSION_REQUEST";
        var account_id = 10905;
        var region_id = 1;
        var reqs = [];
        reqs.push({
            address: "172.16.2.102",
            port: 11001,
            timeout: 10,
            msgObject: UMessage.makeObject({
                message_type: UMessage.EnumValue(messageType)
            }, {
                get_user_all_permission_request: {
                    account_id: account_id,
                    region_id: region_id,
                    _extensionType_: messageType.toLowerCase()
                }
            })
        });

        var resArray = module.exports(self, reqs);
        //GLOBAL.logger.info(resArray);
        process.exit();
    }).run();
}
