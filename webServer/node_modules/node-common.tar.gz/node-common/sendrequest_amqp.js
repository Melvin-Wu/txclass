var Task = require("./task.js");
var Future = require("fibers/future");
var Wait  = Future.wait;
var UMessage = require("./umessage.js");

module.exports = function(task, reqArray) {
/*
    exchange: reqExchange, 
    key: "UCLOUD.UCM.GET_CONFIG_REQUEST", 
    msgObject: obj, 
    channel: self.channel, 
    options: {replyTo: self.replyQueue.queue}, 
*/
    var resArray = [];
    var resIndex = {};
    var reqCount = 0;
    var resCount = 0;
    reqArray.forEach(function(val) {
        val.msgObject.head.source_entity = task.id;
        var buf = UMessage.Serialize(val.msgObject);
        resIndex[val.msgObject.head.flow_no] = reqCount++;
        val.channel.publish(val.exchange, val.key, buf, val.options);
    });
}
