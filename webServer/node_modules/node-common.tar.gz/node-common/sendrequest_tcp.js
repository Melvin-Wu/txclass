var Task = require("./task.js");
var Fibers = require("fibers");
var UMessage = require("./umessage.js");
var Net = require('net');

var connectionPool = {};

function getConnection(address, port) {
	var conn_key = address + ":" + port;
	var client = connectionPool[conn_key];
	if ( client) {
        return client;
	} else {
        var f = Fibers.current;

		client = new Net.Socket();
		client.on('timeout', function() {
            delete connectionPool[conn_key];
			client.end();
		})

		client.on('error', function(error) {
            delete connectionPool[conn_key];
			client.end();
		})

		client.connect(port, address, function() {
            connectionPool[conn_key] = client;
            f.run(client);
		});
        return Fibers.yield()
	}
}

module.exports = function(task, reqArray) {
	/*
    connection: connection, 
    address: ip address/hostname
    port: port
    msgObject: obj, 
*/
	var resArray = [];
	var resIndex = {};
	var reqCount = 0;
	var resCount = 0;

	reqArray.forEach(function(val) {
		val.msgObject.head.source_entity = task.id;
		var buf = UMessage.encodeMessage(val.msgObject);
		resIndex[val.msgObject.head.flow_no] = reqCount++;
        var connection = getConnection( val.address, val.port);
	    connection.write(buf);
	});
}

if (require.main == module) {
	new Task.task(function() {

		var self = this;
		var i = 10;
		var reqs = [];
		for (i = 0; i < 10; i++) {
			reqs.push({
				address: "172.17.0.1",
				port: "2000",
				msgObject: UMessage.makeObject({
					message_type: 1000,
					version: 1,
					dest_entity: 0
				},
				{
					execute_sql_request: {
						db: "uaccount",
						sql: "select * from t_member limit 1"
					}
				})
			});

			reqs.push({
				address: "172.17.0.2",
				port: "2000",
				msgObject: UMessage.makeObject({
					message_type: 1000,
					version: 1,
					dest_entity: 0
				},
				{
					execute_sql_request: {
						db: "uaccount",
						sql: "select * from t_member limit 1"
					}
				})
			});
		}

        for(i=0; i<10; i++){
            module.exports(self, reqs);
        }
	}).run();
}
