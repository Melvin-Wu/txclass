var RpcAmqp= require("./rpc_amqp");
var UMessage = require("./umessage");
var Task = require("./task");

module.exports = function(task, exchange, channel, replyTo, dbname, sqls){

    var message_type = "ucloud.udatabase.EXECUTE_SQL_REQUEST";


    var reqArray = [];

    sqls.forEach(function(sql){
        var head = {
            message_type:UMessage.EnumValue(message_type)
        };
        reqArray.push({
            exchange: exchange,
            key: message_type,
            msgObject: UMessage.makeObject(head, {
                execute_sql_request:{
                    db:dbname, 
                    sql: sql 
                }       
            }),
            channel: channel,
            options: {
                replyTo: replyTo
            }
        });
    });

    return RpcAmqp(task, reqArray);
}


if ( require.main == module ) {

    var Fibers = require("fibers");
    var Task = require("./task");
    var AmqpNetwork = require("./amqp_network");

    Fibers(function(){
        var amqpConnection = AmqpNetwork.init('192.168.8.156:5672', '/', [], ''); 
        var t = new Task.task(function(){
            var self = this;
            var sql = [];
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            sql.push("select count(*) from t_member");
            for(var i=0; i< 100; i++){
                var resArray = module.exports(self, 
                AmqpNetwork.reqExchange, 
                amqpConnection.channel, 
                amqpConnection.replyQueue.queue, 
                "uaccount", 
                sql); 
                console.info(resArray);
            } 
        }); 
        t.run();
    }).run();
}
