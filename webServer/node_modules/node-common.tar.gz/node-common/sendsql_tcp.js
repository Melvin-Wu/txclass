var RpcTcp= require("./rpc_tcp");
var UMessage = require("./umessage");
var Task = require("./task");

module.exports = function(task, address, port, dbname, sqls) {

	var message_type = "ucloud.udatabase.EXECUTE_SQL_REQUEST";

	var reqArray = [];

	sqls.forEach(function(sql) {
		var head = {
			message_type: UMessage.EnumValue(message_type)
		};
		reqArray.push({
			msgObject: UMessage.makeObject(head, {
				execute_sql_request: {
					db: dbname,
					sql: sql
				}
			}),
            address: address,
            port: port
		});
	});

	return RpcTcp(task, reqArray);
}

if (require.main == module) {

	var Task = require("./task");
	var AmqpNetwork = require("./amqp_network");

	var t = new Task.task(function() {
		var self = this;
		var sql = [];
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		sql.push("select count(*) from t_member");
		for (var i = 0; i < 100; i++) {
			var resArray = module.exports(self, "172.17.0.2", 2000, "uaccount", sql);
			console.info(resArray);
		}
	});
	t.run();
}
