var uuid = require("uuid");

var shortId = function(){

    function md5(str){
        var crypto = require("crypto").createHash("md5");
        return crypto.update(str, 'utf8').digest('hex');
    }

    var base = [ 
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 
            'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 
            'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 
            'y', 'z', '0', '1', '2', '3', '4', '5'];

    var hex = md5(uuid.v4());

    var hexlen = hex.length;

    var subhexlen = hexlen / 8;

    var output = [];


    for(var i=0; i < subhexlen; i++){
        var subhex = hex.slice(i*8, (i+1) * 8); 
        var int = 0x3FFFFFFF & (1 * ('0x' + subhex)); 
        var out = "";

        for (var j = 0; j < 6; j++) { 
            var val = 0x0000001F & int; 
            out += base[val]; 
            int = int >> 5; 
        } 

        output.push(out); 
    }
    return output;
}

var getShortId = function(num){
    num = parseInt(num);
    
    var len = Math.ceil(num / 4);      
    var output = [];

    for(var i=0; i<len; i++){
        output = output.concat(shortId()); 
    }
    return output;
}

module.exports = getShortId;
