var Net = require('net');
var UMessage = require('./umessage.js');
var HeadBodyBuffers = require('head_body_buffers').HeadBodyBuffers;
var Task = require('./task.js');
var FunctionPool = require("./function_pool.js").functionPool();
var Fibers = require("fibers");
var translateAddress = require("./translate_address");

var server;

GLOBAL.logger = GLOBAL.logger || console;
GLOBAL.REQUEST_NUMBER = GLOBAL.REQUEST_NUMBER || 0;

exports.init = function(listenAddr, listenPort) {
    GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", listenPort, listenAddr);

    if (!listenAddr || !listenPort) {
        return false;
    }

    if (/^@/.test(listenAddr)) {
        listenAddr = translateAddress(listenAddr);
    }

    server = Net.createServer(function(c) {
        c.buffers = new HeadBodyBuffers(UMessage.tcpHeadSize(), function(data) {
            var ret = UMessage.expectSize(data);
            return ret;
        });

        c.buffers.on('packet', function(buf) {


            var obj;
            try {
                obj = UMessage.decodeMessage(buf);
            } catch (e) {
                GLOBAL.logger.error("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "parse message error", e);
                return;
            }

            var target_entity = 0;
            if (obj.head.version == 2) {
                target_entity = obj.head.dest_entity;
            } else {
                target_entity = obj.head.source_entity;
            }

            var task = Task.taskQueue().get(target_entity);
            if (task) {
                task.run(obj);
            } else {
                var func = FunctionPool.get(obj.head.message_type);
                if (!func) {
                    GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", "discard new message", obj);
                } else {
                    var t = new Task.task(func);
                    t.sendResponse = function(responseObject) {
                        if (c && c._handle) {
                            var b = UMessage.encodeMessage(responseObject.msgObject);
                            GLOBAL.logger.info("REQUEST_NUMBER:", "(" + GLOBAL.REQUEST_NUMBER + ")", UMessage.DebugStringObject(responseObject.msgObject));
                            c.write(b);

                            obj = null;
                            responseObject = null;
                            b = null;
                        }
                    };
                    t.run(obj);
                }
            }
        });

        c.on('error', function(error) {
            if (c.buffers) {
                c.buffers.removeAllListeners();
            }
            c.removeAllListeners();
            c.end();
            c = null;
        })


        c.on('data', function(data) {
            c.buffers.addBuffer(data);
        });

        c.on('end', function() {
            console.info("end");
        });

        c.on('close', function(e) {
            GLOBAL.logger.info("connection on close");
            c.buffers.removeAllListeners();
            c.removeAllListeners();
            c = null;
        });
    });

    server.listen(listenPort, listenAddr, 1024, function() {});
    // var vhost = GLOBAL.context.amqpConfig.get('rabbitmq_vhost');
    return true;
}

if (require.main == module) {
    var Fibers = require("fibers");
    Fibers(function() {
        exports.init('@br0', 2001);
    }).run();
}
