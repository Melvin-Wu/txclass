var Os = require('os');
module.exports = function (listenAddr) {
    var arr = listenAddr.match(/^@(.*)/);
    if ( arr.length < 1 ) {
        return listenAddr;
    }
    var name = arr[1];
    arr = Os.networkInterfaces();
    if ( !arr[name] ) {
        return listenAddr;
    }
    for ( v in arr[name] ) {
        if ( arr[name][v].family == 'IPv4' ) {
            return arr[name][v].address;
        }
    }
    return listenAddr;
}
