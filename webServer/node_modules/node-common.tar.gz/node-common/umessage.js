var protobuf = require("node-protobuf").Protobuf;
var fs = require("fs");
var uuid = require('uuid');
var path = require('path');
var _ = require("underscore");

var dirList = ["${PWD}/wiwo/libs", "${HOME}/wiwo/libs", "/root/wiwo/libs"];

var pathPattern = /(\${([^}]+)})/
var _flowno = 0;

exports.addslashes = addslashes = function(str) {
    str = str.replace(/\\/g, '\\\\');
    str = str.replace(/\'/g, '\\\'');
    str = str.replace(/\"/g, '\\"');
    str = str.replace(/\0/g, '\\0');
    return str;
}


exports.xss_clean = xss_clean = function(obj) {
    var type = typeof obj;
    switch (type) {
        case "object":
            _.each(obj, function(v, i) {
                obj[i] = xss_clean(v);
            });
            break;
        case "string":
            obj = addslashes(obj);
            break;
    }
    return obj;
}

function convert(str, p1, p2) {
    return process.env[p2];
}

function loadDescription() {
    var finalFile;
    for (var k in dirList) {
        try {
            var dir = dirList[k].replace(pathPattern, convert);
            var file = dir + "/umessage.desc";
            var ret = fs.existsSync(file);
            if (ret) {
                finalFile = file;
                break;
            }
        } catch (e) {}
    }
    if (!finalFile) {
        throw "Lookup description file failed";
    }
    //console.log('finalFile: ' + finalFile);
    return finalFile;
}

var pb = new protobuf(fs.readFileSync(loadDescription()));

function random() {
    return Math.floor(Math.random() * (2 ^ 32 - 0) + 0);
}

function flowno() {
    return _flowno++;
}

exports.makeObject = function(head, body) {
    var ret = {};
    ret.head = _.extend({}, head);
    ret.body = _.extend({}, body);

    if (!head.message_type) {
        throw "makeObject need message_type";
    }

    ret.head.version = head.version || 2;
    ret.head.magic_flag = head.magic_flag || 0x12340987;
    ret.head.random_num = head.random_num || random();
    ret.head.flow_no = (head.flow_no != undefined) ? head.flow_no : flowno();
    ret.head.session_no = head.session_no || uuid.v4();
    ret.head.worker_index = head.worker_index || 0;
    ret.head.tint_flag = head.tint_flag || false;
    ret.head.source_entity = head.source_entity || 0;
    ret.head.dest_entity = head.dest_entity || 0;

    ret.body = body;
    return ret;
    //return xss_clean(ret);
}

exports.EnumValue = function(str) {
    return pb.EnumValue(str);
}

exports.Serialize = function(obj, namespace) {
    return pb.Serialize(obj, namespace || "ucloud.UMessage");
}

exports.DebugString = function(buf, namespace, truncate) {
    truncate = parseInt(truncate) || 2048;
    return pb.DebugString(buf, namespace || "ucloud.UMessage").slice(0, truncate);
}

exports.DebugStringObject = function(buf, namespace, truncate) {
    truncate = parseInt(truncate) || 2048;
    return pb.DebugStringObject(buf, namespace || "ucloud.UMessage").slice(0, truncate);
}

exports.Parse = function(buf, namespace) {
    return pb.Parse(buf, namespace || "ucloud.UMessage");
}

exports.ParseFromTcp = function(buf, namespace) {
    return pb.Parse(buf, namespace || "ucloud.UMessage");
}

exports.tcpHeadSize = function() {
    return 4;
}

exports.DescribeMessage = function(key, namespace) {
    return pb.DescribeMessage(key, namespace || "ucloud.UMessage");
}

exports.expectSize = function(buf) {
    var bufLength = buf.length;
    if (bufLength < exports.tcpHeadSize()) {
        return 0;
    }
    return buf.readUInt32BE(0);
}

exports.isEnought = function(buf) {
    var bufLength = buf.length;
    if (bufLength < exports.tcpHeadSize()) {
        return 0;
    }
    var innerLength = exports.expectSize(buf);
    if (bufLength < innerLength) {
        return 0;
    }
    return innerLength;
}

exports.encodeMessage = function(obj, namespace) {
    var dataBuf = exports.Serialize(obj, namespace);
    var lengthBuf = new Buffer(exports.tcpHeadSize());
    lengthBuf.writeUInt32BE(dataBuf.length, 0);
    return Buffer.concat([lengthBuf, dataBuf]);
}

exports.decodeMessage = function(buf, namespace) {
    bufLength = buf.length;
    if (exports.isEnought(buf) <= 0) {
        throw "Invalid buffer";
    }

    var innerLength = buf.readUInt32BE(0);
    var targetBuf = new Buffer(innerLength);
    if (innerLength + exports.tcpHeadSize() != buf.length) {
        throw "Invalid input";
    }
    buf.copy(targetBuf, 0, exports.tcpHeadSize());
    return exports.Parse(targetBuf, namespace);
}

exports.makeResponse = function(request, message_type) {
    var ret = {};
    ret.head = _.extend({}, request.head);
    ret.head.message_type = message_type;
    var source_entity = request.head.source_entity;

    var dest_entity = request.head.dest_entity;
    if (request.head.version == 2) {
        ret.head.source_entity = dest_entity;
        ret.head.dest_entity = source_entity;
    }
    return ret;
}

exports.getExtensionNameByMessageType = function(message_type, namespace) {
    return pb.GetExtensionNameByMessageType(message_type, namespace || "ucloud.Body");
}

exports.getFirstExtension = function(obj, extension_name) {
    if (!_.isArray(obj)) {
        return {
            rc: {
                retcode: -1,
                error_message: "can't find extension by extension_name"
            },
        };
    }

    if (_.isEmpty(obj)) {
        return {
            rc: {
                retcode: -1,
                error_message: "can't find extension by extension_name"
            }
        };
    }

    if (!obj[0].hasOwnProperty('body')) {
        return {
            rc: {
                retcode: -1,
                error_message: "can't find extension by extension_name"
            }
        };
    }

    if (!obj[0].body.hasOwnProperty(extension_name)) {
        return {
            rc: {
                retcode: -1,
                error_message: "can't find extension by extension_name"
            }
        };
    }

    return obj[0]['body'][extension_name];
}

if (require.main == module) {

    // var obj = {
    // 	head: {
    // 		version: 1,
    // 		magic_flag: 305400199,
    // 		random_num: 677011945,
    // 		flow_no: 1,
    // 		session_no: "f683e11c-af10-4119-89cc-a28bf3293a19",
    // 		message_type: 1000,
    // 		worker_index: 999999,
    // 		tint_flag: false,
    // 		source_entity: 0,
    // 		dest_entity: 0,
    // 		call_purpose: "wiwo_tester",
    // 	},
    // 	body: {
    // 		execute_sql_request: {
    // 			db: "mxf",
    // 			sql: "select * from m1 limit 1"
    // 		}
    // 	}
    // };

    var obj = {
        head: {
            message_type: 1000100,
            dest_entity: 0,
            version: 2,
            magic_flag: 305400199,
            random_num: 13,
            flow_no: 0,
            session_no: '5b7e492b-6f5e-4e32-9825-b706544808f3',
            worker_index: 0,
            tint_flag: false,
            source_entity: 1
        },
        body: {
            get_config_request: {
                _extensionType_: 'ucloud.ucm.get_config_request',
                appid: 'UVMAction"',
                serverid: 'vm16',
                instanceid: '0'
            }
        }
    }

    obj = exports.makeObject(obj.head, obj.body);
    //console.info(obj);
    var buf = exports.Serialize(obj);
    //console.info(exports.DebugString(buf));
    //console.info(exports.Parse(buf));
    //console.info(exports.EnumValue("ucloud.udatabase.EXECUTE_SQL_REQUEST"));
    //console.info(exports.getExtensionNameByMessageType(1000));
}
