var ZooKeeper = require("zookeeper");
var Future = require('fibers/future');

var ZkClass = function(options) {
    this.options = options;
    this.conn = null;
}

ZkClass.prototype.connect = function() {
    var f = new Future;
    var self = this;

    self.conn = new ZooKeeper({
        connect: this.options.connect
        ,timeout: this.options.timeout || 200000
        ,debug_level: this.options.debug_level || ZooKeeper.ZOO_LOG_LEVEL_ERROR
        ,host_order_deterministic: this.options.host_order_deterministic || false
    });

    self.conn.connect(function(err){
        if(err) f.throw(err);
        f.return(self.conn);
    });

    return f.wait();
}



ZkClass.prototype.create = function(path, data, flags) {
    var self = this;
    var f = new Future;
    self.conn.a_create(path, data, flags, function(rc, err, path) {
        if (rc != 0) {
            f.
            return (false);
        } else {
            f.
            return (path);
        }
    });
    return f.wait();
}

ZkClass.prototype.get = function(path, watch, time) {
    var self = this;
    var f = new Future;
    var timeout = time || 5000;

    var timer = setTimeout(function() {
        f.return (false);
    }, timeout);

    self.conn.aw_get(path, watch, function(rc, err, stat, data) {
        if(!f.isResolved()){
            clearTimeout(timer);
            if (rc != 0) {
                f.
                return (false);
            } else {
                f.
                return (data);
            }
        }
    });
    return f.wait();
}

ZkClass.prototype.set = function(path, value, version) {
    var self = this;
    var f = new Future;
    self.conn.a_set(path, value, version, function(rc, err, stat) {
        if (rc != 0) {
            f.
            return (false);
        } else {
            f.
            return (true);
        }
    });
    return f.wait();
}

ZkClass.prototype.delete = function(path, version) {
    var self = this;
    var f = new Future;
    self.conn.a_delete_(path, version, function(rc, err) {
        if (rc != 0) {
            f.
            return (false);
        } else {
            f.
            return (true);
        }
    });
    return f.wait();
}

ZkClass.prototype.getChildren = function(path, watch, time) {
    var self = this;
    var f = new Future;
    var timeout = time || 5000;

    var timer = setTimeout(function() {
        f.
        return (false);
    }, timeout);

    self.conn.aw_get_children(path, watch, function(rc, err, children) {
        if(!f.isResolved()){
            clearTimeout(timer);
            if (rc != 0) {
                f.
                return (false);
            } else {
                f.
                return (children);
            }
        }
    });

    return f.wait();
}

ZkClass.prototype.mkdirp = function(path) {
    var self = this;
    var f = new Future;
    self.conn.mkdirp(path, function(err) {
        if (err) {
            f.
            return (false);
        } else {
            f.
            return (path);
        }
    });
    return f.wait();
}

ZkClass.prototype.exists = function(path, watch) {
    var self = this;
    var f = new Future;
    self.conn.a_exists(path, watch, function(rc, err, stat) {
        if (rc != 0) {
            f.
            return (false);
        } else {
            f.
            return (true);
        }
    });
    return f.wait();
}

ZkClass.prototype.close = function() {
    var self = this;
    self.conn.close();
}

module.exports = ZkClass;
